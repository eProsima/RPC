var hierarchy =
[
    [ "eprosima::rpc::protocol::rest::_FastBuffer_iterator", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1___fast_buffer__iterator.html", null ],
    [ "eprosima::rpc::transport::BossProcess", "classeprosima_1_1rpc_1_1transport_1_1_boss_process.html", null ],
    [ "FooREST::FooResource::Emptyvoid", "class_foo_r_e_s_t_1_1_foo_resource_1_1_emptyvoid.html", null ],
    [ "enable_shared_from_this", null, [
      [ "eprosima::rpc::transport::TCPEndpoint", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_endpoint.html", null ]
    ] ],
    [ "eprosima::rpc::transport::Endpoint", "classeprosima_1_1rpc_1_1transport_1_1_endpoint.html", [
      [ "eprosima::rpc::transport::TCPEndpoint", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_endpoint.html", null ]
    ] ],
    [ "exception", null, [
      [ "eprosima::rpc::exception::Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html", [
        [ "eprosima::rpc::exception::SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html", [
          [ "eprosima::rpc::exception::BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html", null ],
          [ "eprosima::rpc::exception::ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html", null ],
          [ "eprosima::rpc::exception::IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html", null ],
          [ "eprosima::rpc::exception::InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html", null ],
          [ "eprosima::rpc::exception::ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html", null ],
          [ "eprosima::rpc::exception::ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html", null ],
          [ "eprosima::rpc::exception::ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html", null ]
        ] ],
        [ "eprosima::rpc::exception::UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html", null ]
      ] ]
    ] ],
    [ "eprosima::rpc::protocol::rest::FastBuffer", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_fast_buffer.html", null ],
    [ "FooREST::FooResourceServerImpl", "class_foo_r_e_s_t_1_1_foo_resource_server_impl.html", null ],
    [ "eprosima::rpc::protocol::rest::HTTPData", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_data.html", null ],
    [ "eprosima::rpc::transport::HttpMessage", "classeprosima_1_1rpc_1_1transport_1_1_http_message.html", null ],
    [ "eprosima::rpc::protocol::rest::HTTPMethod", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_method.html", null ],
    [ "eprosima::rpc::protocol::rest::HTTPParam", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_param.html", null ],
    [ "eprosima::rpc::protocol::rest::HTTPParameters", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_parameters.html", null ],
    [ "eprosima::rpc::protocol::rest::HTTPResponseCode", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_response_code.html", null ],
    [ "eprosima::rpc::protocol::rest::HTTPUri", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_uri.html", null ],
    [ "eprosima::rpc::protocol::rest::HTTPVersion", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_version.html", null ],
    [ "noncopyable", null, [
      [ "eprosima::rpc::transport::TCPEndpoint", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_endpoint.html", null ]
    ] ],
    [ "eprosima::rpc::protocol::Protocol", "classeprosima_1_1rpc_1_1protocol_1_1_protocol.html", [
      [ "eprosima::rpc::protocol::FooRESTProtocol", "classeprosima_1_1rpc_1_1protocol_1_1_foo_r_e_s_t_protocol.html", [
        [ "eprosima::rpc::protocol::rest::FooRESTProtocol", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_foo_r_e_s_t_protocol.html", null ]
      ] ]
    ] ],
    [ "eprosima::rpc::proxy::Proxy", "classeprosima_1_1rpc_1_1proxy_1_1_proxy.html", [
      [ "FooREST::FooResourceProxy", "class_foo_r_e_s_t_1_1_foo_resource_proxy.html", null ]
    ] ],
    [ "RESOURCES_BASE_URI", "interface_r_e_s_o_u_r_c_e_s___b_a_s_e___u_r_i.html", null ],
    [ "eprosima::rpc::protocol::rest::RESTSerializer", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_r_e_s_t_serializer.html", null ],
    [ "eprosima::rpc::server::Server", "classeprosima_1_1rpc_1_1server_1_1_server.html", [
      [ "FooREST::FooResourceServer", "class_foo_r_e_s_t_1_1_foo_resource_server.html", null ]
    ] ],
    [ "eprosima::rpc::strategy::ServerStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy.html", [
      [ "eprosima::rpc::strategy::SingleThreadStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_single_thread_strategy.html", null ],
      [ "eprosima::rpc::strategy::ThreadPerRequestStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_thread_per_request_strategy.html", null ],
      [ "eprosima::rpc::strategy::ThreadPoolStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_thread_pool_strategy.html", null ]
    ] ],
    [ "eprosima::rpc::strategy::ServerStrategyImpl", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl.html", null ],
    [ "eprosima::rpc::transport::Transport", "classeprosima_1_1rpc_1_1transport_1_1_transport.html", [
      [ "eprosima::rpc::transport::ProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1_proxy_transport.html", [
        [ "eprosima::rpc::transport::HttpProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1_http_proxy_transport.html", null ],
        [ "eprosima::rpc::transport::TCPProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_proxy_transport.html", null ]
      ] ],
      [ "eprosima::rpc::transport::ServerTransport", "classeprosima_1_1rpc_1_1transport_1_1_server_transport.html", [
        [ "eprosima::rpc::transport::HttpServerTransport", "classeprosima_1_1rpc_1_1transport_1_1_http_server_transport.html", null ],
        [ "eprosima::rpc::transport::TCPServerTransport", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_server_transport.html", null ]
      ] ]
    ] ]
];