var class_foo_r_e_s_t_1_1_foo_resource_proxy =
[
    [ "FooResourceProxy", "class_foo_r_e_s_t_1_1_foo_resource_proxy.html#aa81610f90adc17a1661f2feb14fc2d52", null ],
    [ "~FooResourceProxy", "class_foo_r_e_s_t_1_1_foo_resource_proxy.html#aeb4ce6ff04b6af0a6329af4500e46e93", null ],
    [ "FooProcedure", "class_foo_r_e_s_t_1_1_foo_resource_proxy.html#a138cc091c9b4e11b9c4a8ef449cdc334", null ]
];