var searchData=
[
  ['resources_5fbase_5furi',['RESOURCES_BASE_URI',['../interface_r_e_s_o_u_r_c_e_s___b_a_s_e___u_r_i.html',1,'']]],
  ['restserializer',['RESTSerializer',['../classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_r_e_s_t_serializer.html',1,'eprosima::rpc::protocol::rest']]]
];
