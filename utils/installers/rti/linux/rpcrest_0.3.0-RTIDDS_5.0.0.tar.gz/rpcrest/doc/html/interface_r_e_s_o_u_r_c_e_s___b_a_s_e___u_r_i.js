var interface_r_e_s_o_u_r_c_e_s___b_a_s_e___u_r_i =
[
    [ "value", "interface_r_e_s_o_u_r_c_e_s___b_a_s_e___u_r_i.html#a9ea7f2863e23823cc599d202f5bfe5d4", null ]
];