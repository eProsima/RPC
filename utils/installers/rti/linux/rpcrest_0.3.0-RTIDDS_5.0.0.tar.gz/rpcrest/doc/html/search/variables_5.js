var searchData=
[
  ['socket_5f',['socket_',['../classeprosima_1_1rpc_1_1transport_1_1_t_c_p_endpoint.html#a215d0a1ed287aa61db153f1314abd007',1,'eprosima::rpc::transport::TCPEndpoint']]]
];
