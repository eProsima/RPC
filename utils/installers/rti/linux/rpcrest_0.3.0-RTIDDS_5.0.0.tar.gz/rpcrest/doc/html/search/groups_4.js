var searchData=
[
  ['server_20module',['Server Module',['../group___s_e_r_v_e_r_m_o_d_u_l_e.html',1,'']]],
  ['strategies',['Strategies',['../group___s_t_r_a_t_e_g_i_e_s_m_o_d_u_l_e.html',1,'']]]
];
