var namespaces =
[
    [ "FooREST", null, [
      [ "FooResource", "namespace_foo_r_e_s_t_1_1_foo_resource.html", null ]
    ] ]
];