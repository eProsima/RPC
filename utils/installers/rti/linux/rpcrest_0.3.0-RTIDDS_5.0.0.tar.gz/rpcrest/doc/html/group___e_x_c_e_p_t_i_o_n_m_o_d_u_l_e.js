var group___e_x_c_e_p_t_i_o_n_m_o_d_u_l_e =
[
    [ "BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html", [
      [ "BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#a88955367d6c048868aa87359d389f50b", null ],
      [ "BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#a2e510cbc8805bee03f79129f84db5cc8", null ],
      [ "BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#a06caa59c39d59ead4daaad7d5781dfe3", null ],
      [ "BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#ab7db623d25b9b157cb795984109045ab", null ],
      [ "~BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#a507519fc9cedfc04b6c492fa1011be77", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#ad5cb47375ef6733f4d7d740088b44d16", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#a929e587fa4afbf1b86563f9badaae97e", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html#ad27ffba9509bb73229ba26411130ef9d", null ]
    ] ],
    [ "ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html", [
      [ "ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#aca8e4824dc76c2c5849851a875076840", null ],
      [ "ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#a6e760406fd2d57063e6214467f1963e0", null ],
      [ "ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#aaed9672ce1cc72786e4c5d37de518d4d", null ],
      [ "ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#a1471bfeeab9bb45a0e421f952e45ad35", null ],
      [ "~ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#afd034b891a604b1cae2dc9570401b2b3", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#a0c4f27e124ec2407159492a7d4062fcd", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#a230f43c34be46c41ac7f78d5aae10f6d", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html#ae85d7512f9e855c53b8d5fb0828e61cc", null ]
    ] ],
    [ "Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html", [
      [ "~Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html#afa844343e1ed3d874bdc9e8ed20193e5", null ],
      [ "Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html#ad6077ed208f0940af8ce8a847db4da97", null ],
      [ "Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html#a0c904dddaf18aab6c5cc65d7dc3bf1f8", null ],
      [ "Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html#a24705e2ccfb13ca5d7ad0d6b92e4542c", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_exception.html#a95f7b53b0c030dc3b26387f237e55ea9", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_exception.html#a748876e31551b18d684ea4a81bef6966", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_exception.html#a5d6dd890a5cf216a8ca26eddba93b0d5", null ]
    ] ],
    [ "IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html", [
      [ "IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#a70f86bbbca0ca4e8d357713e0e53cd58", null ],
      [ "IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#a65cc042f4d4a9c065097fbc507dc2d79", null ],
      [ "IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#a791731f2b7993de299d5fd2e96adf67f", null ],
      [ "IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#a3d2e896238e381a436da778881df8a0d", null ],
      [ "~IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#a7b5a2340f4a015c4cb8e451fdd82241b", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#ab34a5a480797e23f6009086d41bfc726", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#a6a6054d22841f34631e009fd2f0c0737", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html#a7b18b362bade945493872f7866fa0ac3", null ]
    ] ],
    [ "InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html", [
      [ "InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#a5e50f944233c40790b225f7f91d00a7f", null ],
      [ "InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#add184cfde111fe1a734b11fd041d122b", null ],
      [ "InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#a21d1dc758db036fdcfbfc9150ca6a933", null ],
      [ "InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#ab93e59a848e2a71dc1df3d321c977f6d", null ],
      [ "~InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#aa258f98a82da2451bdec94a2c4c78d05", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#ac12d424d461dd333824b309657f36b71", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#a048ca2df24199cdbd119eff515a0f1e0", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html#a14490ec685ef53163d1e93ded2f9ca04", null ]
    ] ],
    [ "ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html", [
      [ "ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#acfc3747f57c69091ca82d336c8827ae5", null ],
      [ "ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#a1df47409564249aeba8b0e2623da9996", null ],
      [ "ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#ac83a63e5f09b8cefc2f7ebbf71f45c45", null ],
      [ "ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#a65a996331f5929c20a4a07c41ba8b0e2", null ],
      [ "~ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#a75b2d3bab350e6cb531d323468d529af", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#aab7fec9b12358518415d9798787a0934", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#a7c3e143bae005be26d7496cd52805cf2", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html#a5521a651bb1ea3be375539f15a17d50e", null ]
    ] ],
    [ "ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html", [
      [ "ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#a139ebcf31b2fff420ab86a7d0bfead3f", null ],
      [ "ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#ab69e659917be689e8a180d02d78b761b", null ],
      [ "ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#a8653ca5f340332e53eb41a363909fbe0", null ],
      [ "ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#a9bd40be4f27657d7c884638cec918161", null ],
      [ "~ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#a02408989c1896d27dd924ba895e515f2", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#a61c2a686589c3ef71826dda9e32dc964", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#a7b50570ce419c0f28ad075925ee8ca74", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html#a37faf478c421b0e9920c9307eec3babb", null ]
    ] ],
    [ "ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html", [
      [ "ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#afc5d5d16288ee677c69b7473fe2282f8", null ],
      [ "ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#aaa9198fe4d3f32ee8dd9ba191d64f48d", null ],
      [ "ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#ade2faf737c9fcf070dcab91d0888900f", null ],
      [ "ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#a1fcf9844a691822ecfb50300fa3bf01c", null ],
      [ "~ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#a77ade1be4f190116c592020caa940a1c", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#a9dc20c666ba96a1ca3813214c2795ad5", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#a6e22291aa6b816819e36c46f8b7de034", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html#a12db52a61bf3c1b00403310695188fb8", null ]
    ] ],
    [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html", [
      [ "~SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a169a0b3a81a56655e2b0ba64d7a19919", null ],
      [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a6fad1d345c95fc251c075a33bb79e889", null ],
      [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a19c973fc141584c7e85bd111459f11f1", null ],
      [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#af93dab9cd3dd634ab8fc043144c435fd", null ],
      [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#af98cee67b982639420e65ed9c211217a", null ],
      [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a6e77f8cfa6c28ebbad77b332ff6f6383", null ],
      [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a6a14071756e638be3e03f3d278dfd7e2", null ],
      [ "minor", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a1c34006eb85d3f9fd0a16ebd55577837", null ],
      [ "minor", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a397ee3e8b1f75b29a9a2646965d6490d", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a11929d662e78be866371a9f87580bcf5", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#af0faa93b0b036257aabee08c17aab455", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#aac0288518424adeb012d728ad91a49e5", null ],
      [ "what", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#af38ab4c49720f1777dd16a66159e619f", null ]
    ] ],
    [ "UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html", [
      [ "~UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html#ab693ed9827216fecbec29b606cebc8a2", null ],
      [ "UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html#a0ed8772281dc67251018ade02ce46c24", null ],
      [ "UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html#ab7676a2e716565f87e4d86d919c26945", null ],
      [ "UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html#a25bde3dd23056938a986b8b242f2f466", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html#a04815f996efc019aeba1107d0c882f3e", null ],
      [ "operator=", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html#a947f6fed24c1db5de2c37ffc127cdd6f", null ],
      [ "raise", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html#a5c54e4940b36b5637a9c324ce3819f6d", null ]
    ] ]
];