var group___r_p_c_a_p_i_r_e_f_e_r_e_n_c_e =
[
    [ "Client Module", "group___p_r_o_x_y_m_o_d_u_l_e.html", "group___p_r_o_x_y_m_o_d_u_l_e" ],
    [ "Server Module", "group___s_e_r_v_e_r_m_o_d_u_l_e.html", "group___s_e_r_v_e_r_m_o_d_u_l_e" ],
    [ "Exceptions", "group___e_x_c_e_p_t_i_o_n_m_o_d_u_l_e.html", "group___e_x_c_e_p_t_i_o_n_m_o_d_u_l_e" ],
    [ "Transports", "group___t_r_a_n_s_p_o_r_t_m_o_d_u_l_e.html", "group___t_r_a_n_s_p_o_r_t_m_o_d_u_l_e" ],
    [ "Protocols", "group___p_r_o_t_o_c_o_l_m_o_d_u_l_e.html", "group___p_r_o_t_o_c_o_l_m_o_d_u_l_e" ]
];