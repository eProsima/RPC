var annotated =
[
    [ "eprosima", null, [
      [ "rpc", null, [
        [ "exception", null, [
          [ "BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception" ],
          [ "ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception" ],
          [ "Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_exception" ],
          [ "IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception" ],
          [ "InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception" ],
          [ "ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception" ],
          [ "ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception" ],
          [ "ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception" ],
          [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_system_exception" ],
          [ "UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_user_exception" ]
        ] ],
        [ "protocol", null, [
          [ "rest", null, [
            [ "_FastBuffer_iterator", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1___fast_buffer__iterator.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1___fast_buffer__iterator" ],
            [ "FastBuffer", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_fast_buffer.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_fast_buffer" ],
            [ "HTTPMethod", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_method.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_method" ],
            [ "HTTPUri", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_uri.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_uri" ],
            [ "HTTPParam", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_param.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_param" ],
            [ "HTTPParameters", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_parameters.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_parameters" ],
            [ "HTTPVersion", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_version.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_version" ],
            [ "HTTPData", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_data.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_data" ],
            [ "HTTPResponseCode", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_response_code.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_h_t_t_p_response_code" ],
            [ "RESTSerializer", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_r_e_s_t_serializer.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_r_e_s_t_serializer" ],
            [ "FooRESTProtocol", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_foo_r_e_s_t_protocol.html", "classeprosima_1_1rpc_1_1protocol_1_1rest_1_1_foo_r_e_s_t_protocol" ]
          ] ],
          [ "Protocol", "classeprosima_1_1rpc_1_1protocol_1_1_protocol.html", "classeprosima_1_1rpc_1_1protocol_1_1_protocol" ],
          [ "FooRESTProtocol", "classeprosima_1_1rpc_1_1protocol_1_1_foo_r_e_s_t_protocol.html", "classeprosima_1_1rpc_1_1protocol_1_1_foo_r_e_s_t_protocol" ]
        ] ],
        [ "proxy", null, [
          [ "Proxy", "classeprosima_1_1rpc_1_1proxy_1_1_proxy.html", "classeprosima_1_1rpc_1_1proxy_1_1_proxy" ]
        ] ],
        [ "server", null, [
          [ "Server", "classeprosima_1_1rpc_1_1server_1_1_server.html", "classeprosima_1_1rpc_1_1server_1_1_server" ]
        ] ],
        [ "strategy", null, [
          [ "ServerStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy" ],
          [ "ServerStrategyImpl", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl.html", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl" ],
          [ "SingleThreadStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_single_thread_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_single_thread_strategy" ],
          [ "ThreadPerRequestStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_thread_per_request_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_thread_per_request_strategy" ],
          [ "ThreadPoolStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_thread_pool_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_thread_pool_strategy" ]
        ] ],
        [ "transport", null, [
          [ "Endpoint", "classeprosima_1_1rpc_1_1transport_1_1_endpoint.html", "classeprosima_1_1rpc_1_1transport_1_1_endpoint" ],
          [ "TCPEndpoint", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_endpoint.html", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_endpoint" ],
          [ "HttpProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1_http_proxy_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_http_proxy_transport" ],
          [ "HttpServerTransport", "classeprosima_1_1rpc_1_1transport_1_1_http_server_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_http_server_transport" ],
          [ "HttpMessage", "classeprosima_1_1rpc_1_1transport_1_1_http_message.html", "classeprosima_1_1rpc_1_1transport_1_1_http_message" ],
          [ "ProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1_proxy_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_proxy_transport" ],
          [ "ServerTransport", "classeprosima_1_1rpc_1_1transport_1_1_server_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_server_transport" ],
          [ "TCPProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_proxy_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_proxy_transport" ],
          [ "TCPServerTransport", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_server_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_t_c_p_server_transport" ],
          [ "BossProcess", "classeprosima_1_1rpc_1_1transport_1_1_boss_process.html", "classeprosima_1_1rpc_1_1transport_1_1_boss_process" ],
          [ "Transport", "classeprosima_1_1rpc_1_1transport_1_1_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_transport" ]
        ] ]
      ] ]
    ] ],
    [ "FooREST", null, [
      [ "FooResource", "namespace_foo_r_e_s_t_1_1_foo_resource.html", "namespace_foo_r_e_s_t_1_1_foo_resource" ],
      [ "FooResourceProxy", "class_foo_r_e_s_t_1_1_foo_resource_proxy.html", "class_foo_r_e_s_t_1_1_foo_resource_proxy" ],
      [ "FooResourceServer", "class_foo_r_e_s_t_1_1_foo_resource_server.html", "class_foo_r_e_s_t_1_1_foo_resource_server" ],
      [ "FooResourceServerImpl", "class_foo_r_e_s_t_1_1_foo_resource_server_impl.html", "class_foo_r_e_s_t_1_1_foo_resource_server_impl" ]
    ] ],
    [ "RESOURCES_BASE_URI", "interface_r_e_s_o_u_r_c_e_s___b_a_s_e___u_r_i.html", "interface_r_e_s_o_u_r_c_e_s___b_a_s_e___u_r_i" ]
];