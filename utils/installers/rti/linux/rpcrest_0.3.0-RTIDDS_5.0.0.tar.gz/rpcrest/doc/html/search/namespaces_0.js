var searchData=
[
  ['fooresource',['FooResource',['../namespace_foo_r_e_s_t_1_1_foo_resource.html',1,'FooREST']]]
];
