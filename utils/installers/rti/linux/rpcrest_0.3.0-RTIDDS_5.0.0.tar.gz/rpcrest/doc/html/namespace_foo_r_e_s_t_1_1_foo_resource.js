var namespace_foo_r_e_s_t_1_1_foo_resource =
[
    [ "Emptyvoid", "class_foo_r_e_s_t_1_1_foo_resource_1_1_emptyvoid.html", "class_foo_r_e_s_t_1_1_foo_resource_1_1_emptyvoid" ]
];