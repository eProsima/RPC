var class_identification =
[
    [ "value_1", "class_identification.html#a1d3ecb27afd47a34d316eb54e653e4a8", null ],
    [ "value_2", "class_identification.html#aec516f6a261971545a9577139f0456a5", null ],
    [ "value_3", "class_identification.html#a61c9f5f682fe05914fd5a9a0aeff6435", null ],
    [ "value_4", "class_identification.html#ac09491e2c74e48c57cdccb11bdf37ada", null ]
];