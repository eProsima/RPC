var class_foo_d_d_s_1_1_foo_plugin =
[
    [ "FooProcedureReplyPlugin", "class_foo_d_d_s_1_1_foo_plugin_1_1_foo_procedure_reply_plugin.html", null ],
    [ "FooProcedureRequestPlugin", "class_foo_d_d_s_1_1_foo_plugin_1_1_foo_procedure_request_plugin.html", null ]
];