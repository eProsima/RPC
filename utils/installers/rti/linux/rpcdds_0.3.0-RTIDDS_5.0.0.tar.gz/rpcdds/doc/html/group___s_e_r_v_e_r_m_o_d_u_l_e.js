var group___s_e_r_v_e_r_m_o_d_u_l_e =
[
    [ "Strategies", "group___s_t_r_a_t_e_g_i_e_s_m_o_d_u_l_e.html", "group___s_t_r_a_t_e_g_i_e_s_m_o_d_u_l_e" ],
    [ "Server", "classeprosima_1_1rpc_1_1server_1_1_server.html", [
      [ "Server", "classeprosima_1_1rpc_1_1server_1_1_server.html#a8ffed15071bffbeef4f2f8eae2dcd130", null ],
      [ "~Server", "classeprosima_1_1rpc_1_1server_1_1_server.html#aedff2fab1bf99f793f88583601e81901", null ],
      [ "serve", "classeprosima_1_1rpc_1_1server_1_1_server.html#af510ab4862c01428f351614df45defcc", null ],
      [ "stop", "classeprosima_1_1rpc_1_1server_1_1_server.html#ac23bc51bddd2a96f6fb799548f416a26", null ]
    ] ],
    [ "ServerStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy.html", [
      [ "ServerStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy.html#a6e285ecffe2f4b494f0696521c41c0ec", null ],
      [ "~ServerStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy.html#a022221603bcafddbf833c52ab42aa906", null ],
      [ "getImpl", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy.html#a09e58e77f377ea2a63fb6533a0a5daa9", null ]
    ] ],
    [ "ServerStrategyImpl", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl.html", [
      [ "ServerStrategyImpl", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl.html#a958444e1c4c8d0de21c7adf88a3811fe", null ],
      [ "~ServerStrategyImpl", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl.html#a24182e87fcc011d8615a3127252092ac", null ],
      [ "schedule", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl.html#a3a82048dacaa7db902b32982ce8d2c40", null ]
    ] ]
];