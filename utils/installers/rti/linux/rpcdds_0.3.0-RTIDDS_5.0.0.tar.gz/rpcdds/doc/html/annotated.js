var annotated =
[
    [ "eprosima", null, [
      [ "rpc", null, [
        [ "exception", null, [
          [ "BadParamException", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_bad_param_exception" ],
          [ "ClientInternalException", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_client_internal_exception" ],
          [ "Exception", "classeprosima_1_1rpc_1_1exception_1_1_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_exception" ],
          [ "IncompatibleException", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_incompatible_exception" ],
          [ "InitializeException", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_initialize_exception" ],
          [ "ServerInternalException", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_server_internal_exception" ],
          [ "ServerNotFoundException", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_server_not_found_exception" ],
          [ "ServerTimeoutException", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_server_timeout_exception" ],
          [ "SystemException", "classeprosima_1_1rpc_1_1exception_1_1_system_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_system_exception" ],
          [ "UserException", "classeprosima_1_1rpc_1_1exception_1_1_user_exception.html", "classeprosima_1_1rpc_1_1exception_1_1_user_exception" ]
        ] ],
        [ "protocol", null, [
          [ "dds", null, [
            [ "Identification", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_identification.html", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_identification" ],
            [ "RequestHeader", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_request_header.html", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_request_header" ],
            [ "ReplyHeader", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_reply_header.html", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_reply_header" ],
            [ "IdentificationPlugin", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_identification_plugin.html", null ],
            [ "RequestHeaderPlugin", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_request_header_plugin.html", null ],
            [ "ReplyHeaderPlugin", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_reply_header_plugin.html", null ],
            [ "FooDDSProtocol", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_foo_d_d_s_protocol.html", "classeprosima_1_1rpc_1_1protocol_1_1dds_1_1_foo_d_d_s_protocol" ]
          ] ],
          [ "Protocol", "classeprosima_1_1rpc_1_1protocol_1_1_protocol.html", "classeprosima_1_1rpc_1_1protocol_1_1_protocol" ],
          [ "FooDDSProtocol", "classeprosima_1_1rpc_1_1protocol_1_1_foo_d_d_s_protocol.html", "classeprosima_1_1rpc_1_1protocol_1_1_foo_d_d_s_protocol" ]
        ] ],
        [ "proxy", null, [
          [ "Proxy", "classeprosima_1_1rpc_1_1proxy_1_1_proxy.html", "classeprosima_1_1rpc_1_1proxy_1_1_proxy" ]
        ] ],
        [ "server", null, [
          [ "Server", "classeprosima_1_1rpc_1_1server_1_1_server.html", "classeprosima_1_1rpc_1_1server_1_1_server" ]
        ] ],
        [ "strategy", null, [
          [ "ServerStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy" ],
          [ "ServerStrategyImpl", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl.html", "classeprosima_1_1rpc_1_1strategy_1_1_server_strategy_impl" ],
          [ "SingleThreadStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_single_thread_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_single_thread_strategy" ],
          [ "ThreadPerRequestStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_thread_per_request_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_thread_per_request_strategy" ],
          [ "ThreadPoolStrategy", "classeprosima_1_1rpc_1_1strategy_1_1_thread_pool_strategy.html", "classeprosima_1_1rpc_1_1strategy_1_1_thread_pool_strategy" ]
        ] ],
        [ "transport", null, [
          [ "dds", null, [
            [ "AsyncThread", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_async_thread.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_async_thread" ],
            [ "ProxyProcedureEndpoint", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_proxy_procedure_endpoint.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_proxy_procedure_endpoint" ],
            [ "ServerProcedureEndpoint", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_server_procedure_endpoint.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_server_procedure_endpoint" ],
            [ "DDSAsyncTask", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_d_d_s_async_task.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_d_d_s_async_task" ],
            [ "ProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_proxy_transport.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_proxy_transport" ],
            [ "ServerTransport", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_server_transport.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_server_transport" ],
            [ "TCPProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_t_c_p_proxy_transport.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_t_c_p_proxy_transport" ],
            [ "TCPServerTransport", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_t_c_p_server_transport.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_t_c_p_server_transport" ],
            [ "Transport", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_transport.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_transport" ],
            [ "UDPProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_u_d_p_proxy_transport.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_u_d_p_proxy_transport" ],
            [ "UDPServerTransport", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_u_d_p_server_transport.html", "classeprosima_1_1rpc_1_1transport_1_1dds_1_1_u_d_p_server_transport" ]
          ] ],
          [ "AsyncTask", "classeprosima_1_1rpc_1_1transport_1_1_async_task.html", "classeprosima_1_1rpc_1_1transport_1_1_async_task" ],
          [ "Endpoint", "classeprosima_1_1rpc_1_1transport_1_1_endpoint.html", "classeprosima_1_1rpc_1_1transport_1_1_endpoint" ],
          [ "ProxyTransport", "classeprosima_1_1rpc_1_1transport_1_1_proxy_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_proxy_transport" ],
          [ "ServerTransport", "classeprosima_1_1rpc_1_1transport_1_1_server_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_server_transport" ],
          [ "Transport", "classeprosima_1_1rpc_1_1transport_1_1_transport.html", "classeprosima_1_1rpc_1_1transport_1_1_transport" ]
        ] ]
      ] ]
    ] ],
    [ "FooDDS", null, [
      [ "Foo", "namespace_foo_d_d_s_1_1_foo.html", null ],
      [ "Foo", "interface_foo_d_d_s_1_1_foo.html", "interface_foo_d_d_s_1_1_foo" ],
      [ "Foo_FooProcedureCallbackHandler", "class_foo_d_d_s_1_1_foo___foo_procedure_callback_handler.html", "class_foo_d_d_s_1_1_foo___foo_procedure_callback_handler" ],
      [ "Foo_FooProcedureTask", "class_foo_d_d_s_1_1_foo___foo_procedure_task.html", "class_foo_d_d_s_1_1_foo___foo_procedure_task" ],
      [ "FooProxy", "class_foo_d_d_s_1_1_foo_proxy.html", "class_foo_d_d_s_1_1_foo_proxy" ],
      [ "Foo_FooProcedureRequest", "class_foo_d_d_s_1_1_foo___foo_procedure_request.html", "class_foo_d_d_s_1_1_foo___foo_procedure_request" ],
      [ "Foo_FooProcedureReply", "class_foo_d_d_s_1_1_foo___foo_procedure_reply.html", "class_foo_d_d_s_1_1_foo___foo_procedure_reply" ],
      [ "FooServer", "class_foo_d_d_s_1_1_foo_server.html", "class_foo_d_d_s_1_1_foo_server" ],
      [ "FooServerImpl", "class_foo_d_d_s_1_1_foo_server_impl.html", "class_foo_d_d_s_1_1_foo_server_impl" ],
      [ "FooRequest_union", "class_foo_d_d_s_1_1_foo_request__union.html", "class_foo_d_d_s_1_1_foo_request__union" ],
      [ "FooRequest", "class_foo_d_d_s_1_1_foo_request.html", "class_foo_d_d_s_1_1_foo_request" ],
      [ "FooReply_union", "class_foo_d_d_s_1_1_foo_reply__union.html", "class_foo_d_d_s_1_1_foo_reply__union" ],
      [ "FooReply", "class_foo_d_d_s_1_1_foo_reply.html", "class_foo_d_d_s_1_1_foo_reply" ],
      [ "FooPlugin", "class_foo_d_d_s_1_1_foo_plugin.html", "class_foo_d_d_s_1_1_foo_plugin" ],
      [ "FooRequestDataReader", "class_foo_d_d_s_1_1_foo_request_data_reader.html", "class_foo_d_d_s_1_1_foo_request_data_reader" ],
      [ "FooRequestDataWriter", "class_foo_d_d_s_1_1_foo_request_data_writer.html", "class_foo_d_d_s_1_1_foo_request_data_writer" ],
      [ "FooRequest_unionPlugin", "class_foo_d_d_s_1_1_foo_request__union_plugin.html", null ],
      [ "FooRequestPlugin", "class_foo_d_d_s_1_1_foo_request_plugin.html", "class_foo_d_d_s_1_1_foo_request_plugin" ],
      [ "FooReplyDataReader", "class_foo_d_d_s_1_1_foo_reply_data_reader.html", "class_foo_d_d_s_1_1_foo_reply_data_reader" ],
      [ "FooReplyDataWriter", "class_foo_d_d_s_1_1_foo_reply_data_writer.html", "class_foo_d_d_s_1_1_foo_reply_data_writer" ],
      [ "FooReply_unionPlugin", "class_foo_d_d_s_1_1_foo_reply__union_plugin.html", null ],
      [ "FooReplyPlugin", "class_foo_d_d_s_1_1_foo_reply_plugin.html", "class_foo_d_d_s_1_1_foo_reply_plugin" ]
    ] ],
    [ "Identification", "class_identification.html", "class_identification" ],
    [ "ReplyHeader", "class_reply_header.html", "class_reply_header" ],
    [ "RequestHeader", "class_request_header.html", "class_request_header" ]
];