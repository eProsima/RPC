var class_request_header =
[
    [ "clientId", "class_request_header.html#a3c8464c738820a45d7b573bdbd82b193", null ],
    [ "remoteServiceName", "class_request_header.html#a506c43368e03f9fa9b12b5fe8b3a83f2", null ],
    [ "requestSequenceNumber", "class_request_header.html#aed46f8282294fa3da6091c963a4f434e", null ]
];