var class_foo_d_d_s_1_1_foo_request_plugin =
[
    [ "create_datareaderI", "class_foo_d_d_s_1_1_foo_request_plugin.html#a615f9c5aea8978fb9d16bd7eaeba0d3a", null ],
    [ "create_datawriterI", "class_foo_d_d_s_1_1_foo_request_plugin.html#a5d5f510db6e8c4ee6deddbaaa6f68d56", null ],
    [ "destroy_datareaderI", "class_foo_d_d_s_1_1_foo_request_plugin.html#a1a887ef70adfc833f62f14c11ce6c999", null ],
    [ "destroy_datawriterI", "class_foo_d_d_s_1_1_foo_request_plugin.html#a0fed4154e0503408b8f586c8afc7bd65", null ]
];