var namespaces =
[
    [ "FooDDS", null, [
      [ "Foo", "namespace_foo_d_d_s_1_1_foo.html", null ]
    ] ]
];