var class_foo_d_d_s_1_1_foo_request_data_reader =
[
    [ "FooRequestDataReader", "class_foo_d_d_s_1_1_foo_request_data_reader.html#ab85e2285e67775e6823cbe3f1398b3a5", null ]
];