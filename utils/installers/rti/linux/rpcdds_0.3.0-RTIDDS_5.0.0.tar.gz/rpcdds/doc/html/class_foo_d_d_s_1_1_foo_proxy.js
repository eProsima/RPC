var class_foo_d_d_s_1_1_foo_proxy =
[
    [ "FooProxy", "class_foo_d_d_s_1_1_foo_proxy.html#a5aa90086050d744d61e86ff5db95f22c", null ],
    [ "~FooProxy", "class_foo_d_d_s_1_1_foo_proxy.html#a811ecbcb0a3ebb68ce9fa38f89adf3ca", null ],
    [ "FooProcedure", "class_foo_d_d_s_1_1_foo_proxy.html#a9b0523b98a8b2edf38e3fdff57b805f0", null ],
    [ "FooProcedure_async", "class_foo_d_d_s_1_1_foo_proxy.html#ab3e498ea332e2fe03a699a2cd97e4bac", null ]
];