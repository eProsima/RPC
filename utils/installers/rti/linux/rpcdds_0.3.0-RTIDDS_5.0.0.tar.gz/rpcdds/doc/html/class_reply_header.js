var class_reply_header =
[
    [ "clientId", "class_reply_header.html#abacc73185b5462902976ad07dd9a19f5", null ],
    [ "requestSequenceNumber", "class_reply_header.html#a213650ebadd70761af760c7053d2accb", null ],
    [ "rpcddsRetCode", "class_reply_header.html#adb8c4e9d3352c34d841138fd13d6b5dd", null ],
    [ "rpcddsRetMsg", "class_reply_header.html#a56f856308c25ef5738f8898342c94aef", null ]
];