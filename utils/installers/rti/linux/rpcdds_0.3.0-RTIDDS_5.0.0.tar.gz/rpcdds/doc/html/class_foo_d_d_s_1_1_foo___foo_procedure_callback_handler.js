var class_foo_d_d_s_1_1_foo___foo_procedure_callback_handler =
[
    [ "FooProcedure", "class_foo_d_d_s_1_1_foo___foo_procedure_callback_handler.html#afc2eb32ca1d413383e98459983a2d4ad", null ],
    [ "on_exception", "class_foo_d_d_s_1_1_foo___foo_procedure_callback_handler.html#a386d63f531d9870546612aa220ef2197", null ]
];