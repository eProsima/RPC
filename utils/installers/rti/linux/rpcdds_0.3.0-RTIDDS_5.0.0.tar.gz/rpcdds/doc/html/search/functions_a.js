var searchData=
[
  ['minor',['minor',['../classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a1c34006eb85d3f9fd0a16ebd55577837',1,'eprosima::rpc::exception::SystemException::minor() const '],['../classeprosima_1_1rpc_1_1exception_1_1_system_exception.html#a397ee3e8b1f75b29a9a2646965d6490d',1,'eprosima::rpc::exception::SystemException::minor(const int32_t &amp;minor)']]]
];
