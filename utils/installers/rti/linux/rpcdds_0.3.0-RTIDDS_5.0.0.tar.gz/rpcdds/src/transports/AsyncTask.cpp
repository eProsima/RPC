/*************************************************************************
 * Copyright (c) 2013 eProsima. All rights reserved.
 *
 * This copy of FASTRPC is licensed to you under the terms described in the
 * FASTRPC_LICENSE file included in this distribution.
 *
 *************************************************************************/

#include "rpcdds/transports/AsyncTask.h"

using namespace eprosima::rpc;
using namespace ::transport;

AsyncTask::AsyncTask() 
{
}

AsyncTask::~AsyncTask()
{
}
